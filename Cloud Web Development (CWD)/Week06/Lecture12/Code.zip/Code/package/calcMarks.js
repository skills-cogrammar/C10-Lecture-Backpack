const lodash = require("lodash");

function getAverage(marks) {
  let sum = 0;
  console.log(`lodash size: ${lodash.size(marks)}`);
  marks.map((mark) => {
    sum += mark;
  });
  let avg = sum / marks.length;
  return avg;
}

function highMark(marks) {
  // marks.reduce(())
  let high = 0;
  marks.map((mark) => {
    if (mark > high) {
      high = mark;
    }
  });
  return high;
}

module.exports = { getAverage, highMark };
