const calcMarks = require("./calcMarks");

//module ES6
// import { getAverage, highMark } from "./calcMarks.js";

for (let i = 0; i < 5; i++) {
  let marks = [10, 50, 70];
  marks.push(i + 50);
  console.log(marks);

  let avg = calcMarks.getAverage(marks);
  let high = calcMarks.highMark(marks);

  //module
  // let avg = getAverage(marks);
  // let high = highMark(marks);

  console.log(`Average: ${avg.toFixed(2)}%`);
  console.log(`Highest Mark: ${high.toFixed(2)}%`);
}
