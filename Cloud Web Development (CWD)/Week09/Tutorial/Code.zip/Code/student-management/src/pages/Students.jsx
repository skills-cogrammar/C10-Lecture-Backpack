import { useState, useEffect } from "react";
import { Container, Table, Button } from "react-bootstrap";
import { Link } from "react-router-dom";

const Students = () => {
  const [students, setStudents] = useState([]);
  //   const [readyForExam, setReadyForExam] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchStudents = async () => {
      try {
        const response = await fetch(import.meta.env.VITE_API_URL);
        if (!response.ok) {
          throw new Error("Failed to fetch data");
        }
        const data = await response.json();
        setStudents(data);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchStudents();
  }, []);

  // Function to add a student to the ready for exam list
  const handleAddToExamList = (student) => {
    const currentExamList =
      JSON.parse(sessionStorage.getItem("examList")) || [];

    if (!currentExamList.some((s) => s.id === student.id)) {
      currentExamList.push(student);
      sessionStorage.setItem("examList", JSON.stringify(currentExamList));
    }
  };

  return (
    <>
      {loading ? (
        <Container>Loading...</Container>
      ) : error ? (
        <Container>Error: {error}</Container>
      ) : (
        <Container className="mt-5">
          <h2>Student List</h2>
          <Table striped bordered hover>
            <thead>
              <tr>
                <th>Name</th>
                <th>Username</th>
                <th>Email Address</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {students.map((student) => (
                <tr key={student.id}>
                  <td>{student.name}</td>
                  <td>{student.username}</td>
                  <td>{student.email}</td>
                  <td>
                    <Button
                      variant="success"
                      onClick={() => handleAddToExamList(student)}
                    >
                      Add to Exam List
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </Table>
          <Link to="/exam-list">
            <Button variant="info">View Exam List</Button>
          </Link>
        </Container>
      )}
    </>
  );
};

export default Students;
