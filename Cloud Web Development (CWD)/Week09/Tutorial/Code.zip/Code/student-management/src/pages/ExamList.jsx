import { useState, useEffect } from "react";
import { Container, Table, Button } from "react-bootstrap";
import { Link } from "react-router-dom";

const ExamList = () => {
  const [readyForExam, setReadyForExam] = useState([]);

  useEffect(() => {
    const storedExamList = JSON.parse(sessionStorage.getItem("examList")) || [];
    setReadyForExam(storedExamList);
  }, []);

  const handleRemoveFromExamList = (studentId) => {
    const updatedList = readyForExam.filter(
      (student) => student.id !== studentId
    );
    setReadyForExam(updatedList);
    sessionStorage.setItem("examList", JSON.stringify(updatedList));
  };

  return (
    <>
      <Container className="mt-5">
        <h2>Students Ready for Exam</h2>
        <Table striped bordered hover>
          <thead>
            <tr>
              <th>Name</th>
              <th>Username</th>
              <th>Email Address</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {readyForExam.map((student) => (
              <tr key={student.id}>
                <td>{student.name}</td>
                <td>{student.username}</td>
                <td>{student.email}</td>
                <td>
                  <Button
                    variant="danger"
                    onClick={() => handleRemoveFromExamList(student.id)}
                  >
                    Remove from Exam List
                  </Button>
                </td>
              </tr>
            ))}
          </tbody>
        </Table>
        <Link to="/students">
          <Button variant="secondary">Back to Student List</Button>
        </Link>
      </Container>
    </>
  );
};

export default ExamList;
