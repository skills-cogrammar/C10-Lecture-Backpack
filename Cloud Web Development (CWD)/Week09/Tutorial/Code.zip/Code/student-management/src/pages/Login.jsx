import { useState, useRef, useEffect } from "react";
import { Button, Container, Form, Navbar } from "react-bootstrap";
import { useNavigate } from "react-router-dom";

function Login() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const userRef = useRef(null);
  const navigate = useNavigate();

  useEffect(() => {
    userRef.current.focus();
  }, []);

  function handleLogin(e) {
    e.preventDefault();

    const storedUsername = import.meta.env.VITE_USERNAME;
    const storedPassword = import.meta.env.VITE_PASSWORD;

    if (username === storedUsername && password === storedPassword) {
      navigate("/students");
    } else {
      setError("Invalid Credentials");
      setUsername("");
      setPassword("");
    }
  }

  return (
    <>
      <Navbar bg="dark" variant="dark" expand="lg">
        <Container>
          <Navbar.Brand>Student Management System</Navbar.Brand>
        </Container>
      </Navbar>
      <Container className="mt-5">
        <h2>Login</h2>
        {error && <div className="alert alert-danger">{error}</div>}
        <Form onSubmit={handleLogin}>
          <Form.Group className="mb-3">
            <Form.Label>Username</Form.Label>
            <Form.Control
              type="text"
              value={username}
              required
              ref={userRef}
              onChange={(e) => setUsername(e.target.value)}
            />
          </Form.Group>
          <Form.Group className="mb-3">
            <Form.Label>Password</Form.Label>
            <Form.Control
              type="password"
              value={password}
              required
              onChange={(e) => setPassword(e.target.value)}
            />
          </Form.Group>
          <Button variant="primary" type="submit">
            Login
          </Button>
        </Form>
      </Container>
    </>
  );
}

export default Login;
