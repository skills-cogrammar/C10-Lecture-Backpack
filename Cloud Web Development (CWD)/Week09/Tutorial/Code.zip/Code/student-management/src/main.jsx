import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { createBrowserRouter, RouterProvider } from "react-router-dom";

import App from "./App.jsx";
import Students from "./pages/Students.jsx";
import Navigation from "./components/Navigation.jsx";
import ExamList from "./pages/ExamList.jsx";

import "bootstrap/dist/css/bootstrap.min.css";

const paths = createBrowserRouter([
  {
    path: "/",
    element: <App />,
  },
  {
    path: "/students",
    element: (
      <>
        <Navigation />
        <Students />
      </>
    ),
  },
  {
    path: "/exam-list",
    element: (
      <>
        <Navigation />
        <ExamList />
      </>
    ),
  },
]);

createRoot(document.getElementById("root")).render(
  <StrictMode>
    <RouterProvider router={paths} />
  </StrictMode>
);
