import { useState } from "react";

function CounterF(props) {
  const [count, setCount] = useState(props.start);

  function add() {
    setCount(count + 1);
  }

  return (
    <>
      <h2>Function Counter</h2>
      <p>Current count: {count}</p>
      <button onClick={add}>+</button>
      <button onClick={() => setCount(count - 1)}>-</button>
    </>
  );
}

export default CounterF;
