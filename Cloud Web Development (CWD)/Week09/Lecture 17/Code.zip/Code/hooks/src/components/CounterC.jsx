import React, { Component } from "react";

class CounterC extends Component {
  constructor(props) {
    super(props);
    this.state = { count: props.start };
    this.add = this.add.bind(this);
    this.sub = this.sub.bind(this);
  }

  add() {
    this.setState({ count: this.state.count + 1 });
  }

  sub() {
    this.setState({ count: this.state.count - 1 });
  }

  render() {
    return (
      <>
        <h2>Class Counter</h2>
        <p>Current count: {this.state.count}</p>
        <button onClick={this.add}>+</button>
        <button onClick={this.sub}>-</button>
      </>
    );
  }
}

export default CounterC;
