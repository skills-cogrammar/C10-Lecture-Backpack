import React, { useState, useEffect, useRef } from "react";
import CounterF from "./components/CounterF";
import CounterC from "./components/CounterC";

const url = import.meta.env.VITE_APIURL;

import "./App.css";

function App() {
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const inputRef = useRef();

  const handleFocus = () => {
    inputRef.current.focus();
  };

  useEffect(() => {
    console.log(test);
    inputRef.current.focus();
    const fetchData = async () => {
      try {
        const response = await fetch(url);
        if (!response.ok) throw new Error("Failed to fetch posts");
        const data = await response.json();
        setPosts(data);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };
    fetchData();

    return () => {
      console.log("Cleanup after the component unmounts or re-renders");
    };
  }, []);

  return (
    <div className="App">
      {/* <h1>Counters</h1>
      <CounterF start={10} />
      <CounterC start={5} /> */}
      <h1>Demonstrating useState, useEffect, and useRef</h1>
      <div className="input-container">
        <input
          type="text"
          ref={inputRef}
          placeholder="Focus me with the button!"
        />
        <button onClick={handleFocus}>Focus Input</button>
      </div>

      {loading ? (
        <p>Loading...</p>
      ) : error ? (
        <p>Error: {error}</p>
      ) : (
        <div className="posts">
          {posts.map((post) => (
            <div className="post" key={post.id}>
              <h3>{post.title}</h3>
              <p>{post.body}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export default App;
