import Navigation from "../routes/Navigation";
import "../App.css";

function Contact() {
  return (
    <>
      <div>
        <Navigation />
        <h1>My Contact Page</h1>
      </div>
    </>
  );
}

export default Contact;
