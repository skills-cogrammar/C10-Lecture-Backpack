import Navigation from "../routes/Navigation";
import "../App.css";

function About() {
  return (
    <>
      <div>
        <Navigation />
        <h1>My About Page</h1>
      </div>
    </>
  );
}

export default About;
