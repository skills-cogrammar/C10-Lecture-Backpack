import { useParams, useLocation } from "react-router-dom";
import Navigation from "../routes/Navigation";
import "../App.css";

function User() {
  const { userId } = useParams();
  const location = useLocation();
  const userData = location.state;

  return (
    <>
      <div>
        <Navigation />
        <h1>User number {userId}</h1>
        <h2>Name: {userData.name}</h2>
        <h2>Surname: {userData.surname}</h2>
      </div>
    </>
  );
}

export default User;
