import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import "./index.css";

import { createBrowserRouter, RouterProvider } from "react-router-dom";
import App from "./App.jsx";
import About from "./pages/About.jsx";
import Contact from "./pages/Contact.jsx";
import User from "./pages/User.jsx";

const paths = createBrowserRouter([
  {
    path: "/",
    element: <App />,
  },
  {
    path: "/about",
    element: <About />,
  },
  {
    path: "/contact",
    element: <Contact />,
  },
  {
    path: "/user/:userId",
    element: <User />,
  },
]);

createRoot(document.getElementById("root")).render(
  <StrictMode>
    <div>
      <h1>
        <small>I'm always here</small>
      </h1>
      <RouterProvider router={paths} />
    </div>
  </StrictMode>
);
