import { Link, useNavigate } from "react-router-dom";
import "../App.css";

function Navigation() {
  const navigate = useNavigate();

  const user1 = {
    id: 1,
    name: "John",
    surname: "Smith",
  };

  const user2 = {
    id: 2,
    name: "Jane",
    surname: "Meyer",
  };

  const user3 = {
    id: 3,
    name: "Bob",
    surname: "Builder",
  };

  const user4 = {
    id: 4,
    name: "Susan",
    surname: "Miles",
  };

  const handleNav = (path, user) => {
    navigate(`/${path}/${user.id}`, { state: user });
  };

  return (
    <>
      <Link className="myLink" to="/">
        Homepage
      </Link>
      <br />
      <Link className="myLink" to="/about">
        About Us
      </Link>
      <br />
      <Link className="myLink" to="/contact">
        Contact Us
      </Link>
      <br />
      <Link className="myLink" to="/user/1" state={user1}>
        User 1
      </Link>
      &nbsp;&nbsp;&nbsp;
      <Link className="myLink" to="/user/2" state={user2}>
        User 2
      </Link>
      <p className="myLink" onClick={() => handleNav("user", user3)}>
        User 3
      </p>
      <p className="myLink" onClick={() => handleNav("user", user4)}>
        User 4
      </p>
    </>
  );
}

export default Navigation;
