const express = require("express");
const fs = require("fs");
const path = require("path");

const app = express();

const port = process.env.PORT || 3000;

app.use(express.json());

const studFilePath = path.join(__dirname, "students.json");

const readData = () => {
  if (fs.existsSync(studFilePath)) {
    const data = fs.readFileSync(studFilePath);
    return JSON.parse(data);
  }
  return [];
};

const writeData = (data) => {
  fs.writeFileSync(studFilePath, JSON.stringify(data, null, 2));
};

app.post("/students", (req, res) => {
  const { name, age, grade } = req.body;
  const students = readData();

  const newStudent = { id: Date.now().toString(), name, age, grade };
  students.push(newStudent);

  writeData(students);

  res.status(201).json(newStudent);
});

app.get("/students", (req, res) => {
  const students = readData();
  res.json(students);
});

app.get("/students/:id", (req, res) => {
  const students = readData();
  const student = students.find((stud) => stud.id === req.params.id);

  if (student) {
    res.json(student);
  } else {
    res.status(404).json({ message: "Student not found" });
  }
});

app.delete("/students/:id", (req, res) => {
  let students = readData();
  let beforeDel = students.length;
  students = students.filter((stud) => stud.id !== req.params.id);
  let afterDel = students.length;

  if (beforeDel === afterDel) {
    res.status(404).json({ message: "Student not found" });
  } else {
    writeData(students);
    res.status(204).send();
  }
});

app.put("/students/:id", (req, res) => {
  const students = readData();
  const studentIndex = students.findIndex((s) => s.id === req.params.id);

  if (studentIndex !== -1) {
    const updatedStudent = { ...students[studentIndex], ...req.body };
    students[studentIndex] = updatedStudent;

    writeData(students);
    res.json(updatedStudent);
  } else {
    res.status(404).json({ message: "Student not found" });
  }
});

app.get("*", (req, res) => {
  res.json({ message: "Resource not found" });
});

app.listen(port, () => {
  console.log(`Server is running on http://localhost:3000`);
});
