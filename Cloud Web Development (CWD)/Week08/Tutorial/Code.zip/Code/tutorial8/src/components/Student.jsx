function Student({ name, surname, age, onRemove }) {
  return (
    <div className="student-card">
      <h3>
        Name: {name} {surname}
      </h3>
      <p>Age: {age}</p>
      <button onClick={onRemove}>Remove</button>
    </div>
  );
}

export default Student;
