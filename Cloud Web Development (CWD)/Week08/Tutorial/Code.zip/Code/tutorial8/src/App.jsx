import "./App.css";
import { useState } from "react";
import Student from "./components/Student";

function App() {
  const [students, setStudents] = useState([]);

  const [name, setName] = useState("");
  const [surname, setSurname] = useState("");
  const [age, setAge] = useState("");

  function addStudent() {
    if (!name || !surname || !age) {
      alert("Please enter required values");
      return;
    }

    setStudents([
      ...students,
      { id: Date.now(), first: name, last: surname, age: age },
    ]);

    setName("");
    setSurname("");
    setAge("");
  }

  function addValue(e) {
    let id = e.target.id;
    let value = e.target.value;
    if (id == "input1") {
      setName(value);
    } else if (id == "input2") {
      setSurname(value);
    } else {
      setAge(value);
    }
  }

  function delStudent(delId) {
    setStudents(students.filter((stud) => stud.id !== delId));
  }

  return (
    <div className="App">
      <h1>Student Management</h1>
      <div className="form">
        <input
          type="text"
          id="input1"
          placeholder="Enter student name"
          value={name}
          onChange={addValue}
        />
        <input
          type="text"
          id="input2"
          placeholder="Enter student surname"
          value={surname}
          onChange={addValue}
        />
        <input
          type="number"
          id="input3"
          placeholder="Enter student age"
          value={age}
          onChange={addValue}
        />
        <button onClick={addStudent}>Add Student</button>
      </div>
      {/* <p>
        Testing student: {name} {surname} {age}
      </p> */}
      {/* <p>Testing array: {JSON.stringify(students)}</p> */}
      <div className="students-list">
        {students.length === 0 ? (
          <p>No students Added</p>
        ) : (
          <p>Number of students : {students.length}</p>
        )}
        {students.map((student) => (
          <Student
            key={student.id}
            name={student.first}
            surname={student.last}
            age={student.age}
            onRemove={() => delStudent(student.id)}
          />
        ))}
      </div>
    </div>
  );
}

export default App;
