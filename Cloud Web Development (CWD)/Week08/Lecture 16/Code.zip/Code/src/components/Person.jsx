import { React, useState } from "react";
// import React from "react";

function Person(props) {
  const [count1, setCount1] = useState(0);
  const [count2, setCount2] = useState(0);
  const [fistName, setFirstName] = useState("");

  let myMarks = props.marks;
  let displayMarks = myMarks.map((mark, index) => {
    return (
      <li key={`Mark${index}`}>
        Mark {index + 1}: {mark}
      </li>
    );
  });

  function addCount() {
    let number = count1 + 1;
    // number++;
    setCount1(number);
  }

  function getUser(e) {
    console.log(e.target.value);
    setFirstName(e.target.value);
  }

  return (
    <>
      <h3>Name: {props.name}</h3>
      <h4>Age: {props.age}</h4>
      <h5>Marks:</h5>
      <ul>{displayMarks}</ul>
      <button onClick={() => props.call(props.age)}>Check something</button>
      <br />
      <button onClick={addCount}>Count (Event Handler)</button>
      <label>You clicked the button {count1} times (Event Handler)</label>
      <br />
      <button onClick={() => setCount2(count2 + 1)}>Count (inline)</button>
      <label>You clicked the button {count2} times (inline)</label>
      <br />
      <input
        type="text"
        value={fistName}
        placeholder="Please enter your name"
        onChange={getUser}
      />
    </>
  );
}

export default Person;
