import { Button, Container } from "react-bootstrap";
import "bootstrap/dist/css/bootstrap.min.css";
import Person from "./components/Person";

function App() {
  function mouseOver() {
    console.log("You hovered");
  }

  function mouseOut(arg) {
    console.log(`You leaving so soon? Here is my age: ${arg}`);
  }

  function handleClick(e, first) {
    console.log(e);
    console.log(`${first} says hi`);
    // e.target.innerHTML = "You clicked";
  }

  return (
    <>
      <Container>
        <h1 onMouseOver={mouseOver}>Local State Management and Events</h1>
        <Button onClick={(event) => handleClick(event, "Pieter")}>
          Click me
        </Button>
        <Person name="John" call={mouseOut} age={55} marks={[88, 77, 90, 22]} />
      </Container>
    </>
  );
}

export default App;
